/* Лёгкий движок частиц: конфетти, салюты, искры — один canvas поверх всего */

export type Shape = "rect" | "circle" | "star" | "ribbon";

interface Particle {
  kind: "confetti" | "rocket" | "spark" | "ember";
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  rot: number;
  vr: number;
  shape: Shape;
  life: number;
  maxLife: number;
  gravity: number;
  drag: number;
  flicker: number;
  explodeAt?: number;
}

export const PALETTE = [
  "#ff5d9e",
  "#ff9ec7",
  "#f6c96d",
  "#b18cff",
  "#8b5cf6",
  "#6ee7ff",
  "#ffffff",
  "#ffb07c",
];

class FX {
  private canvas: HTMLCanvasElement | null = null;
  private ctx: CanvasRenderingContext2D | null = null;
  private particles: Particle[] = [];
  private running = false;
  private dpr = 1;
  private intensity = 1;

  setIntensity(v: number) {
    this.intensity = Math.max(0.4, Math.min(1, v));
  }

  private ensure() {
    if (this.canvas) return;
    const c = document.createElement("canvas");
    c.style.cssText =
      "position:fixed;inset:0;width:100vw;height:100vh;pointer-events:none;z-index:999;";
    document.body.appendChild(c);
    this.canvas = c;
    this.ctx = c.getContext("2d");
    this.resize();
    window.addEventListener("resize", () => this.resize());
  }

  private resize() {
    if (!this.canvas) return;
    this.dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.canvas.width = innerWidth * this.dpr;
    this.canvas.height = innerHeight * this.dpr;
    this.ctx?.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
  }

  private start() {
    if (this.running) return;
    this.running = true;
    const loop = () => {
      this.step();
      if (this.particles.length > 0) {
        requestAnimationFrame(loop);
      } else {
        this.running = false;
        this.ctx?.clearRect(0, 0, innerWidth, innerHeight);
      }
    };
    requestAnimationFrame(loop);
  }

  private step() {
    const ctx = this.ctx;
    if (!ctx) return;
    ctx.clearRect(0, 0, innerWidth, innerHeight);
    const next: Particle[] = [];

    for (const p of this.particles) {
      p.life += 1;
      if (p.life >= p.maxLife) continue;

      p.vx *= p.drag;
      p.vy = p.vy * p.drag + p.gravity;
      p.x += p.vx;
      p.y += p.vy;
      p.rot += p.vr;

      // ракета взрывается на вершине
      if (p.kind === "rocket") {
        this.spawnTrail(p);
        if (p.vy > -1.2 || p.life > (p.explodeAt ?? 60)) {
          this.spawnFirework(p.x, p.y, p.color);
          continue;
        }
      }

      const fade = 1 - p.life / p.maxLife;
      let alpha = Math.min(1, fade * 2);
      if (p.kind === "spark") {
        alpha *= 0.55 + 0.45 * Math.sin(p.life * p.flicker);
      }

      ctx.save();
      ctx.globalAlpha = Math.max(0, alpha);
      ctx.translate(p.x, p.y);
      ctx.rotate(p.rot);
      ctx.fillStyle = p.color;

      switch (p.shape) {
        case "rect":
          ctx.fillRect(-p.size / 2, -p.size / 3, p.size, p.size * 0.66);
          break;
        case "ribbon":
          ctx.fillRect(-p.size * 0.9, -p.size / 6, p.size * 1.8 * Math.abs(Math.sin(p.life * 0.2) + 0.3), p.size / 3);
          break;
        case "star":
          this.drawStar(ctx, p.size);
          break;
        default:
          ctx.beginPath();
          ctx.arc(0, 0, p.size / 2, 0, Math.PI * 2);
          ctx.fill();
      }
      ctx.restore();

      next.push(p);
    }

    this.particles = next.length > 1600 ? next.slice(next.length - 1600) : next;
  }

  private drawStar(ctx: CanvasRenderingContext2D, r: number) {
    ctx.beginPath();
    for (let i = 0; i < 5; i++) {
      const a = (i * 4 * Math.PI) / 5 - Math.PI / 2;
      const x = Math.cos(a) * r;
      const y = Math.sin(a) * r;
      i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
    }
    ctx.closePath();
    ctx.fill();
  }

  private spawnTrail(p: Particle) {
    if (Math.random() > 0.6) return;
    this.particles.push({
      kind: "ember",
      x: p.x + (Math.random() - 0.5) * 3,
      y: p.y + 6 + Math.random() * 8,
      vx: (Math.random() - 0.5) * 0.5,
      vy: 0.4,
      size: 2.4,
      color: "#f6c96d",
      rot: 0,
      vr: 0,
      shape: "circle",
      life: 0,
      maxLife: 26,
      gravity: 0.01,
      drag: 0.98,
      flicker: 0,
    });
  }

  private spawnFirework(x: number, y: number, base: string) {
    const colors = [base, ...PALETTE.filter((c) => c !== base).slice(0, 3)];
    const count = Math.round((70 + Math.floor(Math.random() * 40)) * this.intensity);
    for (let i = 0; i < count; i++) {
      const angle = (Math.PI * 2 * i) / count + Math.random() * 0.2;
      const speed = 2 + Math.random() * 5.5;
      this.particles.push({
        kind: "spark",
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        size: 2.4 + Math.random() * 3,
        color: colors[Math.floor(Math.random() * colors.length)],
        rot: Math.random() * Math.PI,
        vr: 0,
        shape: Math.random() > 0.75 ? "star" : "circle",
        life: 0,
        maxLife: 70 + Math.random() * 50,
        gravity: 0.045,
        drag: 0.978,
        flicker: 0.25 + Math.random() * 0.2,
      });
    }
  }

  /* --------- публичные эффекты --------- */

  burst(x: number, y: number, opts?: { count?: number; power?: number; colors?: string[]; scalar?: number }) {
    this.ensure();
    const { power = 11, colors = PALETTE, scalar = 1 } = opts ?? {};
    const count = Math.round((opts?.count ?? 90) * this.intensity);
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = (2 + Math.random() * power) * 0.9;
      const size = (5 + Math.random() * 7) * scalar;
      this.particles.push({
        kind: "confetti",
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - power * 0.36,
        size,
        color: colors[Math.floor(Math.random() * colors.length)],
        rot: Math.random() * Math.PI,
        vr: (Math.random() - 0.5) * 0.3,
        shape: (["rect", "circle", "star", "ribbon"] as Shape[])[Math.floor(Math.random() * 4)],
        life: 0,
        maxLife: 110 + Math.random() * 60,
        gravity: 0.16,
        drag: 0.982,
        flicker: 0,
      });
    }
    this.start();
  }

  rain(duration = 2600) {
    this.ensure();
    const end = Date.now() + duration;
    const tick = () => {
      for (let i = 0; i < Math.max(3, Math.round(6 * this.intensity)); i++) {
        this.particles.push({
          kind: "confetti",
          x: Math.random() * innerWidth,
          y: -20,
          vx: (Math.random() - 0.5) * 2,
          vy: 1.5 + Math.random() * 2.5,
          size: 5 + Math.random() * 7,
          color: PALETTE[Math.floor(Math.random() * PALETTE.length)],
          rot: Math.random() * Math.PI,
          vr: (Math.random() - 0.5) * 0.25,
          shape: (["rect", "circle", "star", "ribbon"] as Shape[])[Math.floor(Math.random() * 4)],
          life: 0,
          maxLife: 220,
          gravity: 0.04,
          drag: 0.996,
          flicker: 0,
        });
      }
      this.start();
      if (Date.now() < end) setTimeout(tick, 70);
    };
    tick();
  }

  rocket(x?: number) {
    this.ensure();
    const startX = x ?? innerWidth * (0.15 + Math.random() * 0.7);
    const color = PALETTE[Math.floor(Math.random() * PALETTE.length)];
    this.particles.push({
      kind: "rocket",
      x: startX,
      y: innerHeight + 12,
      vx: (Math.random() - 0.5) * 1.4,
      vy: -(10.5 + Math.random() * 3.5),
      size: 4,
      color,
      rot: 0,
      vr: 0,
      shape: "circle",
      life: 0,
      maxLife: 500,
      gravity: 0.14,
      drag: 0.995,
      flicker: 0,
      explodeAt: 38 + Math.random() * 26,
    });
    this.start();
  }

  show(duration = 9000) {
    this.ensure();
    const end = Date.now() + duration;
    const launch = () => {
      this.rocket();
      if (Math.random() > 0.5) setTimeout(() => this.rocket(), 140);
      if (Date.now() < end) {
        setTimeout(launch, 260 + Math.random() * 420);
      }
    };
    launch();
  }

  sparkle(x: number, y: number, colors = ["#f6c96d", "#ffffff", "#ff9ec7"]) {
    this.ensure();
    for (let i = 0; i < 3; i++) {
      this.particles.push({
        kind: "confetti",
        x: x + (Math.random() - 0.5) * 8,
        y: y + (Math.random() - 0.5) * 8,
        vx: (Math.random() - 0.5) * 1.6,
        vy: (Math.random() - 0.5) * 1.6 - 0.5,
        size: 2.5 + Math.random() * 3.5,
        color: colors[Math.floor(Math.random() * colors.length)],
        rot: Math.random() * Math.PI,
        vr: 0.05,
        shape: "star",
        life: 0,
        maxLife: 40 + Math.random() * 20,
        gravity: 0.02,
        drag: 0.96,
        flicker: 0,
      });
    }
    this.start();
  }
}

let instance: FX | null = null;

export function getFx(): FX {
  if (!instance) instance = new FX();
  return instance;
}
