import { Sparkle } from "lucide-react";
import { Fragment } from "react";

interface Props {
  items: string[];
  className?: string;
  outline?: boolean;
}

export function Marquee({ items, className = "", outline = false }: Props) {
  const row = (
    <>
      {items.map((item, i) => (
        <Fragment key={i}>
          <span
            className={`font-display uppercase font-bold px-6 whitespace-nowrap ${
              outline ? "text-outline" : "text-white/85"
            }`}
          >
            {item}
          </span>
          <Sparkle size={16} className="text-gold-400 shrink-0" />
        </Fragment>
      ))}
    </>
  );

  return (
    <div className={`relative overflow-hidden py-5 border-y border-white/8 bg-white/[0.02] ${className}`}>
      <div className="flex w-max animate-marquee items-center text-2xl sm:text-4xl">
        <div className="flex items-center">{row}</div>
        <div className="flex items-center" aria-hidden>
          {row}
        </div>
      </div>
    </div>
  );
}
