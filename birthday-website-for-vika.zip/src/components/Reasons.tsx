import { useState } from "react";
import { motion } from "framer-motion";
import {
  Laugh, HeartHandshake, Zap, MessagesSquare, Sparkles, Lightbulb, ShieldCheck, Gem, RotateCw, type LucideIcon,
} from "lucide-react";
import { SectionHeading } from "./SectionHeading";
import { getFx } from "../lib/fx";

const EASE = [0.22, 1, 0.36, 1] as const;

interface Reason {
  icon: LucideIcon;
  word: string;
  text: string;
  hue: string;
}

const REASONS: Reason[] = [
  { icon: Laugh, word: "смех", text: "Ты смеёшься так, что рядом невозможно грустить. Это настоящая суперсила.", hue: "from-rosa-500 to-violet-500" },
  { icon: HeartHandshake, word: "поддержка", text: "Ты появляешься ровно тогда, когда нужна больше всего. Словно чувствуешь сердцем.", hue: "from-violet-500 to-sky-400" },
  { icon: Zap, word: "энергия", text: "Даже обычный вторник рядом с тобой превращается в маленький праздник.", hue: "from-gold-400 to-rosa-500" },
  { icon: MessagesSquare, word: "искренность", text: "С тобой можно быть собой — без масок и притворства. Это бесценно.", hue: "from-sky-400 to-violet-500" },
  { icon: Sparkles, word: "красота", text: "Ты красивая — это видно с первой секунды. А харизма делает тебя ещё ярче.", hue: "from-rosa-400 to-gold-400" },
  { icon: ShieldCheck, word: "надёжность", text: "На тебя можно положиться во всём — от секрета до спасения из любой передряги.", hue: "from-violet-500 to-rosa-500" },
  { icon: Lightbulb, word: "вдохновение", text: "После разговоров с тобой хочется мечтать больше и делать смелее.", hue: "from-gold-400 to-sky-400" },
  { icon: Gem, word: "просто ты", text: "И главная причина — просто потому что ты есть. Лучшей причины не существует.", hue: "from-rosa-500 to-gold-400" },
];

function ReasonCard({ reason, index }: { reason: Reason; index: number }) {
  const [flipped, setFlipped] = useState(false);
  const Icon = reason.icon;

  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.65, delay: (index % 4) * 0.09, ease: EASE }}
      className="perspective-1200"
    >
      <motion.button
        onClick={(e) => {
          setFlipped((f) => !f);
          const r = (e.currentTarget as HTMLElement).getBoundingClientRect();
          getFx().sparkle(r.left + r.width / 2, r.top + r.height / 2);
        }}
        whileHover={{ y: -6 }}
        className="relative w-full aspect-[3/4] preserve-3d cursor-pointer text-left"
        animate={{ rotateY: flipped ? 180 : 0 }}
        transition={{ duration: 0.7, ease: [0.4, 0.2, 0.2, 1] }}
        aria-label={`Причина: ${reason.word}`}
      >
        {/* лицевая сторона */}
        <div className="absolute inset-0 backface-hidden glass rounded-3xl p-5 flex flex-col justify-between overflow-hidden">
          <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/40 to-transparent" />
          <span className="font-serif-i text-4xl text-white/25">{String(index + 1).padStart(2, "0")}</span>
          <div className={`mx-auto w-14 h-14 rounded-2xl bg-gradient-to-br ${reason.hue} grid place-items-center shadow-lg rotate-3`}>
            <Icon size={24} className="text-white" strokeWidth={1.8} />
          </div>
          <div>
            <p className="font-display text-sm uppercase tracking-[0.18em] text-white/85">{reason.word}</p>
            <p className="mt-2 inline-flex items-center gap-1.5 text-[11px] text-white/40">
              <RotateCw size={11} />
              нажми
            </p>
          </div>
        </div>

        {/* обратная сторона */}
        <div
          className={`absolute inset-0 backface-hidden rounded-3xl p-5 flex flex-col justify-between bg-gradient-to-br ${reason.hue} overflow-hidden`}
          style={{ transform: "rotateY(180deg)" }}
        >
          <div className="absolute -top-8 -right-8 w-28 h-28 rounded-full bg-white/15 blur-xl" />
          <Sparkles size={18} className="text-white/80" />
          <p className="text-white text-[15px] leading-relaxed font-medium">{reason.text}</p>
          <p className="font-script text-2xl text-white/90">Вика</p>
        </div>
      </motion.button>
    </motion.div>
  );
}

export function Reasons() {
  return (
    <section className="relative py-28 sm:py-36 z-10">
      <div className="max-w-6xl mx-auto px-5 sm:px-8">
        <SectionHeading
          kicker="бесконечный список"
          title="Восемь причин, почему ты"
          accent="лучшая"
          description="На самом деле их гораздо больше — но восемь уже красиво встают в две аккуратные строчки. Переверни каждую."
        />
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5">
          {REASONS.map((r, i) => (
            <ReasonCard key={i} reason={r} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}
