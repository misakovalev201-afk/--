import { useEffect, useRef } from "react";

interface Star {
  x: number;
  y: number;
  r: number;
  phase: number;
  speed: number;
  hue: number;
}

interface Meteor {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
}

export function Starfield() {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const c = canvas.getContext("2d");
    if (!c) return;
    const ctx: CanvasRenderingContext2D = c;

    let w = 0;
    let h = 0;
    const dpr = Math.min(devicePixelRatio || 1, 2);
    let stars: Star[] = [];
    const meteors: Meteor[] = [];
    let raf = 0;
    let meteorTimer = 0;

    const resize = () => {
      w = innerWidth;
      h = innerHeight;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      canvas.style.width = `${w}px`;
      canvas.style.height = `${h}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const count = Math.min(220, Math.floor((w * h) / 9000));
      stars = Array.from({ length: count }, () => ({
        x: Math.random() * w,
        y: Math.random() * h,
        r: 0.4 + Math.random() * 1.4,
        phase: Math.random() * Math.PI * 2,
        speed: 0.4 + Math.random() * 1.2,
        hue: Math.random() > 0.8 ? 320 : Math.random() > 0.5 ? 46 : 260,
      }));
    };

    resize();
    addEventListener("resize", resize);

    const spawnMeteor = () => {
      const fromLeft = Math.random() > 0.5;
      meteors.push({
        x: fromLeft ? -40 : w + 40,
        y: Math.random() * h * 0.4,
        vx: (fromLeft ? 1 : -1) * (6 + Math.random() * 5),
        vy: 2 + Math.random() * 2,
        life: 0,
        maxLife: 60 + Math.random() * 30,
      });
    };

    let t = 0;
    const loop = () => {
      t += 1;
      ctx.clearRect(0, 0, w, h);

      for (const s of stars) {
        const tw = 0.45 + 0.55 * Math.sin(s.phase + t * 0.02 * s.speed);
        ctx.beginPath();
        ctx.fillStyle = `hsla(${s.hue}, 90%, 84%, ${tw})`;
        ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
        ctx.fill();
      }

      meteorTimer -= 1;
      if (meteorTimer <= 0) {
        spawnMeteor();
        meteorTimer = 260 + Math.random() * 420;
      }

      for (let i = meteors.length - 1; i >= 0; i--) {
        const m = meteors[i];
        m.life += 1;
        m.x += m.vx;
        m.y += m.vy;
        if (m.life > m.maxLife) {
          meteors.splice(i, 1);
          continue;
        }
        const a = 1 - m.life / m.maxLife;
        const grad = ctx.createLinearGradient(m.x, m.y, m.x - m.vx * 14, m.y - m.vy * 14);
        grad.addColorStop(0, `rgba(255, 220, 180, ${a})`);
        grad.addColorStop(1, "rgba(255, 220, 180, 0)");
        ctx.strokeStyle = grad;
        ctx.lineWidth = 1.6;
        ctx.beginPath();
        ctx.moveTo(m.x, m.y);
        ctx.lineTo(m.x - m.vx * 14, m.y - m.vy * 14);
        ctx.stroke();
      }

      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);

    return () => {
      cancelAnimationFrame(raf);
      removeEventListener("resize", resize);
    };
  }, []);

  return (
    <div className="fixed inset-0 z-0 pointer-events-none">
      {/* туманности */}
      <div className="absolute -top-40 -left-40 w-[60vw] h-[60vw] rounded-full bg-[radial-gradient(circle,rgba(139,92,246,0.16),transparent_65%)]" />
      <div className="absolute top-1/3 -right-48 w-[55vw] h-[55vw] rounded-full bg-[radial-gradient(circle,rgba(255,93,158,0.12),transparent_65%)]" />
      <div className="absolute bottom-0 left-1/4 w-[50vw] h-[40vw] rounded-full bg-[radial-gradient(circle,rgba(246,201,109,0.07),transparent_65%)]" />
      <canvas ref={ref} className="absolute inset-0" />
    </div>
  );
}
