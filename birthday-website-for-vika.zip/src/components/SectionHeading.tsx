import { motion } from "framer-motion";
import { Sparkles } from "lucide-react";

const EASE = [0.22, 1, 0.36, 1] as const;

interface Props {
  kicker: string;
  title: string;
  accent?: string;
  description?: string;
}

export function SectionHeading({ kicker, title, accent, description }: Props) {
  return (
    <div className="text-center max-w-2xl mx-auto mb-14 sm:mb-20 px-6">
      <motion.span
        initial={{ opacity: 0, y: 18 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-80px" }}
        transition={{ duration: 0.7, ease: EASE }}
        className="inline-flex items-center gap-2.5 glass rounded-full px-5 py-2 text-[10px] sm:text-[11px] tracking-[0.3em] uppercase text-white/60"
      >
        <Sparkles size={13} className="text-rosa-400" />
        {kicker}
        <Sparkles size={13} className="text-rosa-400" />
      </motion.span>

      <motion.h2
        initial={{ opacity: 0, y: 26 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-80px" }}
        transition={{ duration: 0.8, delay: 0.08, ease: EASE }}
        className="mt-6 font-display font-bold text-3xl sm:text-5xl leading-tight"
      >
        {title}{" "}
        {accent && <span className="text-gradient">{accent}</span>}
      </motion.h2>

      {description && (
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.8, delay: 0.16, ease: EASE }}
          className="mt-5 text-white/55 leading-relaxed"
        >
          {description}
        </motion.p>
      )}
    </div>
  );
}
