import { useEffect, useRef, useState } from "react";
import { motion, useMotionValue, useSpring } from "framer-motion";
import { getFx } from "../lib/fx";

export function CursorGlow({ active }: { active: boolean }) {
  const [enabled, setEnabled] = useState(false);
  const x = useMotionValue(-100);
  const y = useMotionValue(-100);
  const sx = useSpring(x, { stiffness: 250, damping: 24, mass: 0.6 });
  const sy = useSpring(y, { stiffness: 250, damping: 24, mass: 0.6 });
  const last = useRef(0);

  useEffect(() => {
    const fine = window.matchMedia("(pointer: fine)").matches;
    if (!fine) return;
    setEnabled(true);

    const onMove = (e: MouseEvent) => {
      x.set(e.clientX);
      y.set(e.clientY);
      const now = performance.now();
      if (now - last.current > 90) {
        last.current = now;
        getFx().sparkle(e.clientX, e.clientY);
      }
    };
    window.addEventListener("mousemove", onMove);
    return () => window.removeEventListener("mousemove", onMove);
  }, [x, y]);

  if (!enabled || !active) return null;

  return (
    <motion.div
      aria-hidden
      className="fixed z-[1000] pointer-events-none -ml-16 -mt-16 w-32 h-32 rounded-full mix-blend-screen"
      style={{
        x: sx,
        y: sy,
        background:
          "radial-gradient(circle, rgba(255,93,158,0.22) 0%, rgba(139,92,246,0.12) 40%, transparent 70%)",
      }}
    />
  );
}
