import { useEffect, useMemo, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Flame, RotateCcw, Sparkles, Wind, MousePointerClick } from "lucide-react";
import { SectionHeading } from "./SectionHeading";
import { getFx } from "../lib/fx";
import { useSound } from "../hooks/useSound";

const EASE = [0.22, 1, 0.36, 1] as const;
const CANDLE_COLORS = ["#ff5d9e", "#f6c96d", "#8b5cf6", "#6ec3ff", "#ff8f6b"];
const CANDLE_HEIGHTS = [64, 74, 66, 78, 68];

/* ---------------- свеча ---------------- */
function Candle({
  lit,
  color,
  height,
  index,
  onBlow,
}: {
  lit: boolean;
  color: string;
  height: number;
  index: number;
  onBlow: () => void;
}) {
  const [smoke, setSmoke] = useState(false);
  const wasLit = useRef(lit);

  useEffect(() => {
    if (wasLit.current && !lit) {
      setSmoke(true);
      const t = setTimeout(() => setSmoke(false), 1300);
      wasLit.current = lit;
      return () => clearTimeout(t);
    }
    wasLit.current = lit;
  }, [lit]);

  return (
    <motion.button
      onClick={onBlow}
      aria-label="Задуть свечу"
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: 0.15 + index * 0.09, duration: 0.6, ease: EASE }}
      whileHover={{ scale: 1.06 }}
      className="relative flex flex-col items-center justify-end cursor-pointer px-1 -mb-[6px] z-10"
      style={{ height: height + 44 }}
    >
      {/* пламя */}
      <AnimatePresence>
        {lit && (
          <motion.div
            key="flame"
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0, transition: { duration: 0.15 } }}
            className="relative flex items-end justify-center h-9 mb-1"
          >
            <span className="absolute bottom-0 w-10 h-14 rounded-full bg-amber-400/40 blur-xl animate-pulse" />
            <motion.span
              style={{ originY: 1 }}
              animate={{
                scaleY: [1, 1.22, 0.9, 1.14, 1],
                scaleX: [1, 0.9, 1.08, 0.94, 1],
                rotate: [-3, 3, -2, 2, 0],
              }}
              transition={{ repeat: Infinity, duration: 0.85 + index * 0.12, ease: "easeInOut" }}
              className="block w-[15px] h-[30px] rounded-[50%_50%_50%_50%/62%_62%_38%_38%] bg-gradient-to-b from-[#fff8d4] via-[#ffd166] to-[#ff8f3e] shadow-[0_0_18px_rgba(255,190,90,0.9)]"
            />
            <span className="absolute bottom-1 w-[5px] h-[10px] rounded-full bg-white/90 blur-[1px]" />
          </motion.div>
        )}
      </AnimatePresence>

      {/* дым */}
      <AnimatePresence>
        {smoke && !lit && (
          <motion.div key="smoke" className="relative h-9 mb-1 w-6">
            {[0, 1, 2].map((i) => (
              <motion.span
                key={i}
                initial={{ opacity: 0.75, y: 0, scale: 0.4 }}
                animate={{ opacity: 0, y: -30 - i * 8, scale: 1.5, x: i % 2 ? 5 : -4 }}
                transition={{ duration: 1.15, delay: i * 0.18, ease: "easeOut" }}
                className="absolute bottom-0 left-1/2 -ml-[5px] w-[10px] h-[10px] rounded-full bg-white/35 blur-[3px]"
              />
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      {/* фитиль */}
      <div className="w-[3px] h-2.5 bg-[#3a2a22] rounded-full" />
      {/* тело свечи */}
      <div
        className="w-[13px] rounded-[4px] shadow-[inset_-2px_0_3px_rgba(0,0,0,0.25)]"
        style={{
          height,
          background: `repeating-linear-gradient(48deg, #fff8ef 0 6px, ${color} 6px 12px)`,
        }}
      />
    </motion.button>
  );
}

/* ---------------- деталь торта ---------------- */
function Frosting({ drips, color = "#fff1dd" }: { drips: { x: number; w: number; h: number }[]; color?: string }) {
  return (
    <div className="relative h-5 rounded-t-[14px] z-10" style={{ background: color }}>
      {drips.map((d, i) => (
        <span
          key={i}
          className="absolute top-full rounded-b-full"
          style={{ left: `${d.x}%`, width: d.w, height: d.h, background: color }}
        />
      ))}
    </div>
  );
}

/* ---------------- секция ---------------- */
export function CakeSection() {
  const [lit, setLit] = useState<boolean[]>(() => Array(5).fill(true));
  const interacted = useRef(false);
  const { whoosh, chime } = useSound();
  const allOut = lit.every((l) => !l);
  const anyLit = lit.some(Boolean);

  const drips = useMemo(
    () =>
      Array.from({ length: 6 }, (_, i) => ({
        x: 7 + i * 16 + ((i * 37) % 5),
        w: 14 + ((i * 13) % 12),
        h: 12 + ((i * 29) % 14),
      })),
    []
  );
  const sprinkles = useMemo(
    () =>
      Array.from({ length: 16 }, (_, i) => ({
        x: 6 + ((i * 61) % 88),
        y: -2 + ((i * 37) % 60),
        rot: (i * 47) % 180,
        color: ["#ff5d9e", "#f6c96d", "#8b5cf6", "#6ec3ff", "#ffffff"][i % 5],
      })),
    []
  );

  useEffect(() => {
    if (allOut && interacted.current) {
      getFx().show(4200);
      getFx().burst(innerWidth / 2, innerHeight / 2, { count: 120, power: 12 });
      chime();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [allOut]);

  const blowOne = (i: number) => {
    interacted.current = true;
    if (!lit[i]) return;
    setLit((prev) => prev.map((v, idx) => (idx === i ? false : v)));
  };

  const blowAll = () => {
    interacted.current = true;
    whoosh();
    lit.forEach((v, i) => {
      if (v) setTimeout(() => setLit((prev) => prev.map((p, idx) => (idx === i ? false : p))), i * 130);
    });
  };

  const relight = () => {
    setLit(Array(5).fill(true));
  };

  return (
    <section id="cake" className="relative py-28 sm:py-36 z-10 overflow-hidden">
      <div className="max-w-5xl mx-auto px-5 sm:px-8">
        <SectionHeading
          kicker="самый важный ритуал"
          title="Загадай желание —"
          accent="и задуй свечи"
          description="Говорят, желание сбывается, если задуть все свечи. Попробуй по одной — или все разом, как настоящая звезда."
        />

        <div className="relative mx-auto w-fit" style={{ animation: "drip-glow 4s ease-in-out infinite" }}>
          {/* сияние за тортом */}
          <div className="absolute -inset-16 rounded-full bg-[radial-gradient(circle,rgba(255,93,158,0.22),transparent_65%)] blur-2xl pointer-events-none" />

          {/* сообщение о желании */}
          <AnimatePresence>
            {allOut && (
              <motion.div
                initial={{ opacity: 0, y: 20, scale: 0.9 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -14, scale: 0.95 }}
                transition={{ duration: 0.7, ease: EASE }}
                className="absolute -top-24 left-1/2 -translate-x-1/2 z-30 w-max max-w-[90vw] pointer-events-none"
              >
                <div className="glass rounded-2xl px-6 py-3.5 text-center shadow-2xl shadow-rosa-500/20">
                  <p className="font-script text-2xl text-gold-300">
                    Желание загадано — оно обязательно сбудется
                  </p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <div className="relative w-[300px] sm:w-[420px]">
            {/* свечи */}
            <div className="relative z-20 flex justify-center items-end gap-2 sm:gap-3 px-10">
              {lit.map((isLit, i) => (
                <Candle
                  key={i}
                  lit={isLit}
                  index={i}
                  color={CANDLE_COLORS[i]}
                  height={CANDLE_HEIGHTS[i]}
                  onBlow={() => blowOne(i)}
                />
              ))}
            </div>

            {/* верхний ярус */}
            <div className="relative mx-auto w-[68%]">
              <div className="relative">
                <Frosting drips={drips.map((d) => ({ ...d, x: d.x * 0.9 + 4 }))} />
                {/* посыпка */}
                {sprinkles.map((s, i) => (
                  <span
                    key={i}
                    className="absolute w-[3px] h-[9px] rounded-full z-20"
                    style={{
                      left: `${s.x}%`,
                      top: s.y,
                      transform: `rotate(${s.rot}deg)`,
                      background: s.color,
                    }}
                  />
                ))}
              </div>
              <div className="h-[84px] sm:h-[100px] rounded-b-[10px] bg-gradient-to-b from-[#b06bd4] via-[#9356c4] to-[#6f3da5] relative overflow-hidden">
                <div className="absolute inset-0 bg-[linear-gradient(105deg,transparent_30%,rgba(255,255,255,0.14)_45%,transparent_60%)]" />
                <div className="absolute bottom-2 inset-x-0 flex justify-center gap-5">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <span key={i} className="w-2 h-2 rounded-full bg-gold-300/80 shadow-[0_0_6px_rgba(246,201,109,0.8)]" />
                  ))}
                </div>
              </div>
            </div>

            {/* нижний ярус */}
            <div className="relative w-full -mt-[6px]">
              <Frosting drips={drips} />
              <div className="h-[96px] sm:h-[120px] rounded-b-[12px] bg-gradient-to-b from-[#ff8fbf] via-[#f56ba6] to-[#d64c88] relative overflow-hidden">
                <div className="absolute inset-0 bg-[linear-gradient(105deg,transparent_30%,rgba(255,255,255,0.16)_45%,transparent_60%)]" />
                <div className="absolute bottom-3 inset-x-0 flex justify-center gap-7">
                  {Array.from({ length: 7 }).map((_, i) => (
                    <span key={i} className="w-2.5 h-2.5 rounded-full bg-white/85 shadow-[0_0_6px_rgba(255,255,255,0.6)]" />
                  ))}
                </div>
              </div>
            </div>

            {/* блюдце */}
            <div className="relative mx-auto w-[118%] -ml-[9%] h-8 -mt-1.5 rounded-[50%] bg-[radial-gradient(ellipse_at_center,rgba(255,255,255,0.22),rgba(255,255,255,0.05)_65%,transparent_75%)] border border-white/12" />
            <div className="mx-auto w-[80%] h-6 rounded-[50%] bg-rosa-500/25 blur-xl -mt-1" />
          </div>
        </div>

        {/* управление */}
        <div className="mt-12 flex flex-col items-center gap-5">
          <div className="flex flex-wrap justify-center gap-4">
            {anyLit && (
              <button
                onClick={blowAll}
                className="btn-glow btn-shine inline-flex items-center gap-2.5 rounded-full bg-gradient-to-r from-violet-500 to-rosa-500 px-7 py-3.5 font-display text-[11px] sm:text-xs tracking-[0.2em] uppercase cursor-pointer"
              >
                <Wind size={16} />
                Задуть все свечи
              </button>
            )}
            {!anyLit && (
              <button
                onClick={relight}
                className="glass inline-flex items-center gap-2.5 rounded-full px-7 py-3.5 font-display text-[11px] sm:text-xs tracking-[0.2em] uppercase text-white/85 hover:text-white hover:border-gold-400/50 transition-colors cursor-pointer"
              >
                <RotateCcw size={16} />
                Зажечь заново
              </button>
            )}
          </div>
          <p className="inline-flex items-center gap-2 text-white/40 text-sm">
            <MousePointerClick size={15} className="text-gold-400/70" />
            или нажми на каждую свечу по очереди
          </p>
          <p className="inline-flex items-center gap-2 text-white/30 text-xs tracking-[0.2em] uppercase">
            <Flame size={13} className="text-rosa-400/70" />
            пять свечей — пять желаний
            <Sparkles size={13} className="text-gold-400/70" />
          </p>
        </div>
      </div>
    </section>
  );
}
