import { useEffect, useState } from "react";
import { motion, useScroll, useSpring } from "framer-motion";
import { Cake, Music, VolumeX } from "lucide-react";
import { useSound } from "../hooks/useSound";

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [playing, setPlaying] = useState(false);
  const { toggleMelody } = useSound();
  const { scrollYProgress } = useScroll();
  const progress = useSpring(scrollYProgress, { stiffness: 140, damping: 26 });

  useEffect(() => {
    const onScroll = () => setScrolled(scrollY > 30);
    onScroll();
    addEventListener("scroll", onScroll, { passive: true });
    return () => removeEventListener("scroll", onScroll);
  }, []);

  return (
    <motion.header
      initial={{ y: -80, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ delay: 0.9, duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-500 ${
        scrolled ? "backdrop-blur-xl bg-night-900/60 border-b border-white/5" : ""
      }`}
    >
      {/* полоса прогресса праздника */}
      <motion.span
        style={{ scaleX: progress }}
        className="absolute bottom-0 left-0 right-0 h-[2.5px] origin-left bg-gradient-to-r from-rosa-500 via-violet-400 to-gold-400 shadow-[0_0_10px_rgba(255,93,158,0.6)]"
      />
      <div className="max-w-6xl mx-auto px-5 sm:px-8 h-16 flex items-center justify-between">
        <a href="#top" className="flex items-center gap-2.5 group">
          <span className="w-9 h-9 rounded-xl bg-gradient-to-br from-rosa-500 via-violet-500 to-gold-400 grid place-items-center shadow-lg shadow-rosa-500/30 group-hover:rotate-12 transition-transform duration-300">
            <Cake size={17} className="text-white" strokeWidth={2.2} />
          </span>
          <span className="font-display text-[11px] sm:text-xs tracking-[0.22em] uppercase text-white/80">
            для <span className="text-gradient font-semibold">Вики</span>
          </span>
        </a>

        <div className="flex items-center gap-2.5">
          <span className="hidden sm:inline-flex items-center gap-2 text-[11px] tracking-[0.2em] uppercase text-white/50 glass rounded-full px-4 py-2">
            18 ноября
          </span>
          <button
            onClick={() => setPlaying(toggleMelody())}
            aria-label={playing ? "Выключить мелодию" : "Включить мелодию"}
            className="w-10 h-10 rounded-full glass grid place-items-center text-white/80 hover:text-white hover:border-rosa-400/50 transition-colors cursor-pointer"
          >
            {playing ? <VolumeX size={16} /> : <Music size={16} />}
          </button>
        </div>
      </div>
    </motion.header>
  );
}
