import { useMemo, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Monitor, Smartphone, Sparkles, ArrowRight, type LucideIcon } from "lucide-react";
import { getFx } from "../lib/fx";

const EASE = [0.22, 1, 0.36, 1] as const;
export type Device = "mobile" | "desktop";

/* декоративные мерцающие точки для экрана выбора */
const TWINKLES = Array.from({ length: 18 }, (_, i) => ({
  left: `${(i * 37 + 11) % 96}%`,
  top: `${(i * 53 + 7) % 92}%`,
  size: 2 + ((i * 7) % 4),
  delay: (i % 6) * 0.5,
  color: i % 3 === 0 ? "bg-rosa-400" : i % 3 === 1 ? "bg-gold-300" : "bg-violet-400",
}));

interface CardProps {
  device: Device;
  icon: LucideIcon;
  title: string;
  sub: string;
  hint: string;
  recommended: boolean;
  index: number;
  onPick: (d: Device, x: number, y: number) => void;
}

function ChoiceCard({ device, icon: Icon, title, sub, hint, recommended, index, onPick }: CardProps) {
  const ref = useRef<HTMLButtonElement>(null);

  return (
    <motion.button
      ref={ref}
      initial={{ opacity: 0, y: 60, rotate: index === 0 ? -3 : 3 }}
      animate={{ opacity: 1, y: 0, rotate: 0 }}
      exit={{ opacity: 0, y: -50, scale: 0.9, transition: { duration: 0.45, delay: index * 0.07 } }}
      transition={{ duration: 0.9, delay: 0.85 + index * 0.15, ease: EASE }}
      whileHover={{ y: -10, rotate: index === 0 ? -1.2 : 1.2 }}
      whileTap={{ scale: 0.96 }}
      onClick={(e) => {
        const r = ref.current?.getBoundingClientRect();
        onPick(device, r ? r.left + r.width / 2 : e.clientX, r ? r.top + r.height / 2 : e.clientY);
      }}
      className="relative group glass rounded-[2rem] p-8 sm:p-10 w-full sm:w-[19rem] text-left overflow-hidden cursor-pointer hover:border-rosa-400/50 transition-colors duration-500"
    >
      {/* блик */}
      <span className="pointer-events-none absolute inset-0 overflow-hidden rounded-[2rem]">
        <span className="absolute top-0 bottom-0 -left-2/3 w-1/3 skew-x-[-22deg] bg-gradient-to-r from-transparent via-white/25 to-transparent transition-all duration-700 group-hover:left-[130%]" />
      </span>
      {/* свечение угла */}
      <span className="absolute -top-12 -right-12 w-36 h-36 rounded-full bg-rosa-500/20 blur-2xl group-hover:bg-rosa-500/35 transition-colors duration-700" />
      <span className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/50 to-transparent" />

      {recommended && (
        <span className="absolute top-4 right-4 inline-flex items-center gap-1.5 rounded-full bg-gold-400/15 border border-gold-400/40 text-gold-300 text-[10px] tracking-[0.14em] uppercase px-3 py-1.5">
          <Sparkles size={11} />
          наверное, это ты
        </span>
      )}

      <motion.span
        animate={{ y: [0, -8, 0], rotate: [-2, 2, -2] }}
        transition={{ repeat: Infinity, duration: 3.8 + index, ease: "easeInOut" }}
        className="block w-16 h-16 rounded-2xl bg-gradient-to-br from-rosa-500 via-violet-500 to-violet-600 grid place-items-center shadow-lg shadow-rosa-500/30 mb-7"
      >
        <Icon size={28} className="text-white" strokeWidth={1.7} />
      </motion.span>

      <p className="font-display font-bold text-2xl">{title}</p>
      <p className="mt-2.5 text-white/55 text-sm leading-relaxed">{sub}</p>

      <span className="mt-7 inline-flex items-center gap-2 text-[11px] tracking-[0.22em] uppercase text-rosa-300 group-hover:gap-3.5 transition-all">
        {hint}
        <ArrowRight size={14} />
      </span>
    </motion.button>
  );
}

export function DeviceGate({ onChoose }: { onChoose: (d: Device) => void }) {
  const recommended: Device = useMemo(
    () => (window.matchMedia("(pointer: fine)").matches ? "desktop" : "mobile"),
    []
  );
  const [picked, setPicked] = useState<Device | null>(null);

  const pick = (d: Device, x: number, y: number) => {
    if (picked) return;
    setPicked(d);
    const fx = getFx();
    fx.burst(x, y, { count: 90, power: 10, colors: ["#ff5d9e", "#f6c96d", "#ffffff"] });
    fx.rain(1500);
    setTimeout(() => onChoose(d), 620);
  };

  return (
    <motion.div
      className="fixed inset-0 z-[200] overflow-hidden bg-night-950/60 backdrop-blur-[26px]"
      exit={{ y: "-100%" }}
      transition={{ duration: 0.95, ease: EASE, delay: 0.35 }}
    >
      {/* аврора */}
      <div aria-hidden className="absolute inset-0 grid place-items-center pointer-events-none">
        <div
          className="w-[150vmax] h-[150vmax] opacity-70 blur-3xl"
          style={{
            background:
              "conic-gradient(from 140deg at 50% 50%, transparent 8%, rgba(255,93,158,0.13) 22%, transparent 38%, rgba(139,92,246,0.15) 55%, transparent 72%, rgba(246,201,109,0.1) 88%, transparent 100%)",
            animation: "aurora-spin 26s linear infinite",
          }}
        />
      </div>
      {/* мерцающие точки */}
      {TWINKLES.map((t, i) => (
        <span
          key={i}
          aria-hidden
          className={`absolute rounded-full star-dot ${t.color}`}
          style={{ left: t.left, top: t.top, width: t.size, height: t.size, animationDelay: `${t.delay}s` }}
        />
      ))}

      {/* контент */}
      <motion.div
        exit={{ opacity: 0, y: -60, transition: { duration: 0.4 } }}
        className="relative h-full flex flex-col items-center justify-center px-6 text-center"
      >
        <motion.span
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.15, ease: EASE }}
          className="inline-flex items-center gap-2.5 glass rounded-full px-5 py-2.5 text-[10px] sm:text-[11px] tracking-[0.3em] uppercase text-white/60"
        >
          <Sparkles size={13} className="text-gold-400" />
          перед началом — один важный вопрос
          <Sparkles size={13} className="text-gold-400" />
        </motion.span>

        <motion.p
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 0.3, ease: EASE }}
          className="mt-8 font-script text-3xl sm:text-4xl text-rosa-300"
        >
          этот сайт свёрстан специально для Вики
        </motion.p>

        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 0.45, ease: EASE }}
          className="mt-4 font-display font-black text-[clamp(2.2rem,7vw,4.6rem)] leading-tight max-w-3xl"
        >
          С чего <span className="text-gradient">открываем</span> праздник?
        </motion.h1>

        <div className="mt-12 sm:mt-14 flex flex-col sm:flex-row items-stretch gap-5 sm:gap-7 w-full sm:w-auto max-w-md sm:max-w-none">
          <ChoiceCard
            device="mobile"
            icon={Smartphone}
            title="Телефон"
            sub="Уютно, в два тапа — шарики лопаются прямо под пальцем."
            hint="всегда под рукой"
            recommended={recommended === "mobile"}
            index={0}
            onPick={pick}
          />
          <ChoiceCard
            device="desktop"
            icon={Monitor}
            title="Компьютер"
            sub="На большом экране ярче: салюты во всю стену и искры за курсором."
            hint="полное погружение"
            recommended={recommended === "desktop"}
            index={1}
            onPick={pick}
          />
        </div>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 1.5 }}
          className="mt-12 text-white/35 text-sm"
        >
          сайт сам подстроит эффекты под твой экран — в любом случае будет красиво
        </motion.p>
      </motion.div>
    </motion.div>
  );
}
