import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { getFx } from "../lib/fx";
import { useSound } from "../hooks/useSound";

export interface BalloonColor {
  main: string;
  light: string;
  dark: string;
}

export const BALLOON_COLORS: BalloonColor[] = [
  { main: "#ff5d9e", light: "#ffb3d3", dark: "#c22e6b" },
  { main: "#f6c96d", light: "#ffe9b8", dark: "#c79a3e" },
  { main: "#8b5cf6", light: "#c4b0ff", dark: "#5f36c9" },
  { main: "#6ec3ff", light: "#bfe4ff", dark: "#3e8fd4" },
  { main: "#ff8f6b", light: "#ffc9b3", dark: "#d4603e" },
];

interface Props {
  left: string;
  top: string;
  size?: number;
  color: BalloonColor;
  seed?: number;
  className?: string;
}

export function Balloon({ left, top, size = 72, color, seed = 0, className = "" }: Props) {
  const [popped, setPopped] = useState(false);
  const [gen, setGen] = useState(0);
  const { pop } = useSound();

  const handlePop = (e: React.MouseEvent) => {
    if (popped) return;
    setPopped(true);
    pop();
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    getFx().burst(rect.left + rect.width / 2, rect.top + rect.height / 2, {
      count: 30,
      power: 7.5,
      colors: [color.main, color.light, "#ffffff"],
      scalar: 0.7,
    });
    setTimeout(() => {
      setGen((g) => g + 1);
      setPopped(false);
    }, 2800 + seed * 400);
  };

  return (
    <div
      className={`absolute pointer-events-none ${className}`}
      style={{ left, top }}
    >
      <AnimatePresence>
        {!popped && (
          <motion.button
            key={gen}
            onClick={handlePop}
            aria-label="Лопнуть шарик"
            initial={{ y: 140, opacity: 0 }}
            animate={{ y: [0, -16 - seed * 2, 0], opacity: 1, rotate: [0, 2.5, -2, 0] }}
            transition={{
              y: { repeat: Infinity, duration: 5.5 + seed * 0.8, ease: "easeInOut" },
              rotate: { repeat: Infinity, duration: 7 + seed, ease: "easeInOut" },
              opacity: { duration: 1.1, delay: 0.8 + seed * 0.15 },
            }}
            whileHover={{ scale: 1.08 }}
            whileTap={{ scale: 0.9 }}
            className="pointer-events-auto cursor-pointer block"
            style={{ filter: "drop-shadow(0 18px 24px rgba(0,0,0,0.35))" }}
          >
            {/* тело шара */}
            <div
              className="relative"
              style={{
                width: size,
                height: size * 1.22,
                borderRadius: "50% 50% 50% 50% / 45% 45% 55% 55%",
                background: `radial-gradient(circle at 32% 26%, ${color.light} 0%, ${color.main} 42%, ${color.dark} 100%)`,
              }}
            >
              {/* блик */}
              <div
                className="absolute rounded-full bg-white/70 blur-[2px]"
                style={{ width: size * 0.16, height: size * 0.3, left: size * 0.22, top: size * 0.16, transform: "rotate(18deg)" }}
              />
              {/* узелок */}
              <div
                className="absolute left-1/2 -translate-x-1/2"
                style={{
                  bottom: -7,
                  width: 0,
                  height: 0,
                  borderLeft: "6px solid transparent",
                  borderRight: "6px solid transparent",
                  borderBottom: `9px solid ${color.dark}`,
                }}
              />
              {/* верёвочка */}
              <svg
                className="absolute left-1/2 -translate-x-1/2"
                style={{ bottom: -72 }}
                width="24"
                height="66"
                viewBox="0 0 24 66"
                fill="none"
              >
                <path
                  d="M12 2 C 4 18, 20 30, 12 46 C 8 54, 14 60, 12 66"
                  stroke="rgba(255,255,255,0.4)"
                  strokeWidth="1.4"
                />
              </svg>
            </div>
          </motion.button>
        )}
      </AnimatePresence>

      {/* вспышка при лопании */}
      <AnimatePresence>
        {popped && (
          <motion.span
            key={`flash-${gen}`}
            initial={{ scale: 0.2, opacity: 0.9 }}
            animate={{ scale: 2.2, opacity: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.45, ease: "easeOut" }}
            className="absolute rounded-full border-2"
            style={{
              width: size,
              height: size,
              borderColor: color.light,
              boxShadow: `0 0 30px ${color.main}`,
            }}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
