import { motion } from "framer-motion";
import { Sparkles, Star, Smile, Gift, Infinity as InfinityIcon, Compass } from "lucide-react";
import { SectionHeading } from "./SectionHeading";

const EASE = [0.22, 1, 0.36, 1] as const;

export function Letter() {
  return (
    <section className="relative py-28 sm:py-36 z-10 overflow-hidden">
      <div className="max-w-6xl mx-auto px-5 sm:px-8">
        <SectionHeading
          kicker="от чистого сердца"
          title="Письмо"
          accent="для тебя"
          description="Некоторые слова лучше писать, чем говорить. Поэтому — вот, на бумаге и с печатью."
        />

        <div className="grid lg:grid-cols-[1fr_1.15fr] gap-10 lg:gap-14 items-center">
          {/* иллюстрация в рамке */}
          <motion.div
            initial={{ opacity: 0, x: -50, rotate: -5 }}
            whileInView={{ opacity: 1, x: 0, rotate: -3 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.9, ease: EASE }}
            whileHover={{ rotate: -1, scale: 1.02 }}
            className="relative mx-auto w-full max-w-md"
          >
            {/* скотч */}
            <div className="absolute -top-3 left-8 w-20 h-7 bg-rosa-300/60 backdrop-blur-sm rotate-[-8deg] rounded-sm z-20 shadow-sm" />
            <div className="absolute -top-3 right-8 w-20 h-7 bg-gold-300/60 backdrop-blur-sm rotate-[7deg] rounded-sm z-20 shadow-sm" />

            <div className="p-3 pb-5 bg-[#fdf7ee] rounded-2xl shadow-[0_30px_60px_-20px_rgba(255,93,158,0.35)]">
              <div className="overflow-hidden rounded-xl">
                <img
                  src="/images/vika-art.jpg"
                  alt="Девушка с шариками под звёздным небом"
                  className="w-full aspect-[4/5] object-cover hover:scale-105 transition-transform duration-700"
                />
              </div>
              <p className="font-script text-2xl text-[#8a5a8e] text-center mt-4">
                такой я тебя вижу — свободной и счастливой
              </p>
            </div>

            {/* парящие искры */}
            {[0, 1, 2].map((i) => (
              <motion.span
                key={i}
                className="absolute z-20"
                style={{ right: `${6 + i * 14}%`, top: `${8 + i * 22}%` }}
                animate={{ y: [0, -12, 0], rotate: [0, 8, 0] }}
                transition={{ repeat: Infinity, duration: 3.4 + i, delay: i * 0.6, ease: "easeInOut" }}
              >
                {i % 2 === 0 ? (
                  <Sparkles size={16 + i * 4} className="text-rosa-400/80" />
                ) : (
                  <Star size={16 + i * 4} className="text-gold-400/80 fill-gold-400/30" />
                )}
              </motion.span>
            ))}
          </motion.div>

          {/* письмо */}
          <motion.div
            initial={{ opacity: 0, x: 50, rotate: 3 }}
            whileInView={{ opacity: 1, x: 0, rotate: 1.2 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.9, ease: EASE }}
            className="relative"
          >
            {/* восковая печать */}
            <div className="absolute -top-6 -right-3 sm:-right-6 w-16 h-16 rounded-full bg-gradient-to-br from-rosa-500 to-violet-500 grid place-items-center shadow-lg shadow-rosa-500/40 rotate-12 z-20 border-4 border-rosa-600/40">
              <Sparkles size={24} className="text-white" />
            </div>

            <div className="bg-[#fffaf2] text-[#4a3560] rounded-2xl p-8 sm:p-11 shadow-[0_35px_70px_-25px_rgba(139,92,246,0.45)] relative overflow-hidden">
              <div className="absolute inset-x-10 top-0 h-px bg-gradient-to-r from-transparent via-rosa-300 to-transparent" />
              <p className="font-script text-4xl sm:text-[2.6rem] leading-snug text-rosa-600 mb-6">
                Дорогая Вика!
              </p>

              <div className="space-y-4 font-serif-i text-lg sm:text-xl leading-relaxed">
                <p>
                  Сегодня — 18 ноября. День, который я бы отметил в календаре красным, даже если
                  бы календарь был против. В этот день на свет появилась ты — и мир сразу стал
                  чуточку ярче.
                </p>
                <p>
                  Спасибо тебе за всё: за смех до слёз, за разговоры обо всём на свете, за
                  «я всегда рядом». С тобой любая тусовка становится лучше, а обычный день —
                  интереснее. Ты красивая, умная и бесконечно классная — и это факт, а не
                  комплимент.
                </p>
                <p>
                  Желаю, чтобы мечты не просто сбывались — а сбывались с фейерверком. Чтобы всё
                  задуманное получалось, а каждый твой день был таким же ярким, как ты сама.
                  Знай: у тебя есть друг, который тобой гордится.
                </p>
              </div>

              {/* пожелания-чипы */}
              <div className="flex flex-wrap gap-2.5 mt-7">
                {[
                  { icon: Sparkles, label: "чуда" },
                  { icon: Smile, label: "улыбок" },
                  { icon: Gift, label: "сюрпризов" },
                  { icon: Compass, label: "приключений" },
                  { icon: InfinityIcon, label: "счастья" },
                ].map(({ icon: ChipIcon, label }) => (
                  <span
                    key={label}
                    className="inline-flex items-center gap-1.5 rounded-full bg-rosa-600/10 text-rosa-600 border border-rosa-600/20 px-3.5 py-1.5 text-sm font-semibold"
                  >
                    <ChipIcon size={13} />
                    {label}
                  </span>
                ))}
              </div>

              <p className="mt-8 text-right font-script text-3xl sm:text-4xl text-[#7a4a8e]">
                твой друг
              </p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
