import { useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Wand2, Quote, Star } from "lucide-react";
import { SectionHeading } from "./SectionHeading";
import { getFx } from "../lib/fx";
import { useSound } from "../hooks/useSound";

const EASE = [0.22, 1, 0.36, 1] as const;

const PREDICTIONS = [
  "В этом году тебя ждёт путешествие, о котором ты давно мечтала — собирай чемодан заранее.",
  "Очень скоро случится встреча, которая многое изменит. Смотри внимательнее по сторонам.",
  "Твоя мечта из разряда «когда-нибудь потом» в этом году наконец скажет: «пора».",
  "Год принесёт столько поводов для смеха, что придётся завести отдельный фотоальбом.",
  "Ты найдёшь занятие, которое будет приносить и вдохновение, и очень приятные бонусы.",
  "В этом году ты станешь ещё красивее. Да, это возможно. Вселенная уже работает над этим.",
  "Тебя ждёт сюрприз от человека, от которого ты его совсем не ждёшь. Приятный, обещаем.",
  "Все «а вдруг не получится» этого года закончатся словами «как же хорошо, что я попробовала».",
  "Год будет щедрым: на обнимашки, на приключения и на идеальные плейлисты под настроение.",
  "Ты научишься чему-то совершенно новому — и все будут спрашивать: «Вика, где ты этому научилась?!»",
  "Самое тёплое воспоминание этого года ещё даже не случилось. Оно уже в пути.",
  "В этом году удача будет ходить за тобой по пятам — как очень преданный щенок.",
];

export function Predictions() {
  const [text, setText] = useState("Здесь появится твоё предсказание на следующий год…");
  const [busy, setBusy] = useState(false);
  const [count, setCount] = useState(0);
  const timers = useRef<number[]>([]);
  const cardRef = useRef<HTMLDivElement>(null);
  const { chime } = useSound();

  const draw = () => {
    if (busy) return;
    setBusy(true);
    let steps = 0;
    const shuffle = () => {
      setText(PREDICTIONS[Math.floor(Math.random() * PREDICTIONS.length)]);
      steps += 1;
      if (steps < 14) {
        timers.current.push(window.setTimeout(shuffle, 55 + steps * 8));
      } else {
        setBusy(false);
        setCount((c) => c + 1);
        chime();
        const r = cardRef.current?.getBoundingClientRect();
        if (r) {
          getFx().burst(r.left + r.width / 2, r.top + r.height / 2, { count: 70, power: 9, scalar: 0.8 });
        }
      }
    };
    shuffle();
  };

  return (
    <section className="relative py-28 sm:py-36 z-10 overflow-hidden">
      {/* призрачная звезда на фоне */}
      <Star
        aria-hidden
        size={420}
        className="absolute -right-24 top-16 text-white/[0.025] rotate-12 pointer-events-none"
        strokeWidth={0.6}
      />

      <div className="max-w-3xl mx-auto px-5 sm:px-8">
        <SectionHeading
          kicker="заглянем в будущее"
          title="Предсказание"
          accent="на новый год жизни"
          description="Магический генератор никогда не ошибается. Ну, почти никогда. Ну, ладно — он всегда прав."
        />

        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.8, ease: EASE }}
          className="relative"
        >
          {/* градиентная рамка */}
          <div className="rounded-[2rem] p-[1.5px] bg-gradient-to-br from-rosa-500/70 via-violet-500/40 to-gold-400/70">
            <div ref={cardRef} className="glass rounded-[calc(2rem-1.5px)] p-8 sm:p-12 text-center relative overflow-hidden">
              <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/50 to-transparent" />
              <Quote size={28} className="mx-auto text-rosa-400 rotate-180 mb-6" strokeWidth={1.6} />

              <div className="min-h-[7.5rem] sm:min-h-[6.5rem] grid place-items-center">
                <AnimatePresence mode="wait">
                  <motion.p
                    key={text}
                    initial={{ opacity: 0, y: 14 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -14 }}
                    transition={{ duration: 0.18 }}
                    className={`text-lg sm:text-2xl leading-relaxed max-w-xl ${
                      busy ? "text-white/40 blur-[0.6px]" : "text-white/90"
                    } font-serif-i`}
                  >
                    {text}
                  </motion.p>
                </AnimatePresence>
              </div>

              <button
                onClick={draw}
                disabled={busy}
                className="btn-glow btn-shine mt-8 inline-flex items-center gap-2.5 rounded-full bg-gradient-to-r from-rosa-500 to-violet-500 px-8 py-4 font-display text-[11px] sm:text-xs tracking-[0.2em] uppercase cursor-pointer disabled:opacity-50 disabled:cursor-wait"
              >
                <Wand2 size={16} className={busy ? "animate-spin" : ""} />
                {count === 0 ? "Раскрыть предсказание" : "Ещё одно"}
              </button>

              {count > 2 && (
                <p className="mt-4 text-white/45 font-script text-xl">
                  генератор устал — столько хорошего сразу
                </p>
              )}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
