import { useEffect, useRef, useState } from "react";
import { motion, useInView } from "framer-motion";
import { Rocket, Sparkles, Star } from "lucide-react";
import { getFx } from "../lib/fx";

const EASE = [0.22, 1, 0.36, 1] as const;

export function Finale() {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: "-25%" });
  const [bursts, setBursts] = useState(0);

  useEffect(() => {
    if (inView) {
      const t = setTimeout(() => getFx().show(5000), 600);
      return () => clearTimeout(t);
    }
  }, [inView]);

  const launch = () => {
    setBursts((b) => b + 1);
    const fx = getFx();
    fx.rocket(innerWidth * 0.5);
    setTimeout(() => fx.rocket(innerWidth * 0.25), 120);
    setTimeout(() => fx.rocket(innerWidth * 0.75), 260);
    fx.show(10000);
  };

  return (
    <section ref={ref} className="relative min-h-[92vh] py-28 z-10 flex items-center overflow-hidden">
      {/* гигантская призрачная надпись */}
      <div aria-hidden className="absolute inset-0 grid place-items-end pb-10 select-none pointer-events-none">
        <span
          className="font-display font-black text-[30vw] leading-none"
          style={{ color: "transparent", WebkitTextStroke: "1.5px rgba(255,255,255,0.035)" }}
        >
          ВИКА
        </span>
      </div>

      <div className="relative max-w-4xl mx-auto px-6 text-center">
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, ease: EASE }}
          className="font-script text-3xl sm:text-4xl text-rosa-300"
        >
          и напоследок —
        </motion.p>

        <motion.h2
          initial={{ opacity: 0, y: 34 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.9, delay: 0.1, ease: EASE }}
          className="mt-4 font-display font-black text-[clamp(2.6rem,8.5vw,6.5rem)] leading-[1.02]"
        >
          Будь счастлива,
          <br />
          <span className="text-gradient">Вика</span>
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.2, ease: EASE }}
          className="mt-7 text-white/55 text-base sm:text-lg max-w-lg mx-auto leading-relaxed"
        >
          Пусть этот год будет таким же ярким, как салют над головой.
          С днём рождения. Ты заслуживаешь всего — и даже немного сверх.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 24, scale: 0.95 }}
          whileInView={{ opacity: 1, y: 0, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.3, ease: EASE }}
          className="mt-12"
        >
          <button
            onClick={launch}
            className="btn-glow btn-shine inline-flex items-center gap-3 rounded-full bg-gradient-to-r from-rosa-500 via-violet-500 to-gold-400 bg-[length:200%_auto] px-10 py-5 font-display text-sm sm:text-base tracking-[0.18em] uppercase text-white cursor-pointer"
          >
            <Rocket size={19} />
            {bursts === 0 ? "Запустить салют" : "Ещё салют!"}
          </button>

          <div className="mt-8 flex items-center justify-center gap-2.5">
            {[0, 1, 2, 3, 4].map((i) => (
              <motion.span
                key={i}
                animate={{ y: [0, -8, 0], scale: [1, 1.15, 1] }}
                transition={{ repeat: Infinity, duration: 2, delay: i * 0.22, ease: "easeInOut" }}
              >
                {i % 2 === 0 ? (
                  <Sparkles size={13 + (i % 3) * 3} className="text-gold-400/70" />
                ) : (
                  <Star size={13 + (i % 3) * 3} className="text-rosa-400/70 fill-rosa-400/30" />
                )}
              </motion.span>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
