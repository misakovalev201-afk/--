import { useEffect, useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Cake, Sparkles, Star } from "lucide-react";
import { SectionHeading } from "./SectionHeading";
import { getFx } from "../lib/fx";

const EASE = [0.22, 1, 0.36, 1] as const;

function plural(n: number, forms: [string, string, string]) {
  const n10 = n % 10;
  const n100 = n % 100;
  if (n10 === 1 && n100 !== 11) return forms[0];
  if (n10 >= 2 && n10 <= 4 && (n100 < 10 || n100 >= 20)) return forms[1];
  return forms[2];
}

function useCountdown() {
  const isToday = useMemo(() => {
    const now = new Date();
    return now.getMonth() === 10 && now.getDate() === 18;
  }, []);

  const target = useMemo(() => {
    const now = new Date();
    let t = new Date(now.getFullYear(), 10, 18, 0, 0, 0);
    if (now.getTime() >= t.getTime()) t = new Date(now.getFullYear() + 1, 10, 18, 0, 0, 0);
    return t;
  }, []);

  const calc = () => {
    const diff = Math.max(0, target.getTime() - Date.now());
    return {
      days: Math.floor(diff / 86400000),
      hours: Math.floor((diff / 3600000) % 24),
      minutes: Math.floor((diff / 60000) % 60),
      seconds: Math.floor((diff / 1000) % 60),
    };
  };

  const [left, setLeft] = useState(calc);

  useEffect(() => {
    const id = setInterval(() => setLeft(calc()), 1000);
    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [target]);

  return { isToday, left };
}

function TimeCard({ value, label, delay }: { value: string; label: string; delay: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 40, scale: 0.9 }}
      whileInView={{ opacity: 1, y: 0, scale: 1 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.7, delay, ease: EASE }}
      className="glass rounded-3xl px-4 sm:px-8 py-6 sm:py-9 text-center relative overflow-hidden group"
    >
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-rosa-400/60 to-transparent" />
      <div className="absolute -top-10 -right-10 w-24 h-24 rounded-full bg-violet-500/20 blur-2xl group-hover:bg-rosa-500/30 transition-colors duration-700" />
      <div className="font-display font-bold text-4xl sm:text-6xl tabular-nums h-[1.2em] relative overflow-hidden">
        <AnimatePresence mode="popLayout" initial={false}>
          <motion.span
            key={value}
            initial={{ y: "105%", opacity: 0 }}
            animate={{ y: "0%", opacity: 1 }}
            exit={{ y: "-105%", opacity: 0 }}
            transition={{ duration: 0.45, ease: EASE }}
            className="block text-gradient"
          >
            {value}
          </motion.span>
        </AnimatePresence>
      </div>
      <div className="mt-3 text-[10px] sm:text-xs tracking-[0.3em] uppercase text-white/50">{label}</div>
    </motion.div>
  );
}

export function Countdown() {
  const { isToday, left } = useCountdown();
  const [celebrated, setCelebrated] = useState(false);

  useEffect(() => {
    if (isToday && !celebrated) {
      setCelebrated(true);
      const t = setTimeout(() => {
        getFx().show(6000);
        getFx().rain(3000);
      }, 800);
      return () => clearTimeout(t);
    }
  }, [isToday, celebrated]);

  return (
    <section id="countdown" className="relative py-28 sm:py-36 z-10">
      <div className="max-w-5xl mx-auto px-5 sm:px-8">
        {isToday ? (
          <>
            <SectionHeading
              kicker="сегодня — 18 ноября"
              title="Этот день"
              accent="настал!"
              description="Вика, с днём рождения! Весь следующие год пусть будет таким же ярким, как этот салют."
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.9, ease: EASE }}
              className="glass rounded-[2.5rem] p-10 sm:p-16 text-center relative overflow-hidden"
            >
              <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-gold-400/70 to-transparent" />
              <p className="font-script text-3xl sm:text-4xl text-rosa-300">с днём рождения,</p>
              <p className="font-display font-black text-gradient text-5xl sm:text-7xl mt-3">ВИКА</p>
              <div className="flex justify-center gap-3 mt-6">
                {[Cake, Sparkles, Star].map((Icon, i) => (
                  <motion.span
                    key={i}
                    animate={{ scale: [1, 1.3, 1] }}
                    transition={{ repeat: Infinity, duration: 1.4, delay: i * 0.2 }}
                  >
                    <Icon size={20} className="text-gold-400" />
                  </motion.span>
                ))}
              </div>
            </motion.div>
          </>
        ) : (
          <>
            <SectionHeading
              kicker="обратный отсчёт"
              title="До твоего дня"
              accent="осталось совсем чуть-чуть"
              description="Каждая секунда приближает 18 ноября — дату, когда мир стал чуточку лучше."
            />
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
              <TimeCard value={String(left.days)} label={plural(left.days, ["день", "дня", "дней"])} delay={0} />
              <TimeCard
                value={String(left.hours).padStart(2, "0")}
                label={plural(left.hours, ["час", "часа", "часов"])}
                delay={0.08}
              />
              <TimeCard
                value={String(left.minutes).padStart(2, "0")}
                label={plural(left.minutes, ["минута", "минуты", "минут"])}
                delay={0.16}
              />
              <TimeCard
                value={String(left.seconds).padStart(2, "0")}
                label={plural(left.seconds, ["секунда", "секунды", "секунд"])}
                delay={0.24}
              />
            </div>
          </>
        )}
      </div>
    </section>
  );
}
