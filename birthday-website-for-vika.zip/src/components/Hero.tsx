import { useEffect } from "react";
import { motion } from "framer-motion";
import { Sparkles, CakeSlice, ChevronDown, Star, PartyPopper, Sparkle } from "lucide-react";
import { getFx } from "../lib/fx";
import { Balloon, BALLOON_COLORS } from "./Balloon";

const EASE = [0.22, 1, 0.36, 1] as const;

function scrollTo(id: string) {
  document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
}

/* маленькие мерцающие звёздочки в hero */
const TWINKLES = [
  { left: "22%", top: "24%", size: 13, delay: 0.2 },
  { left: "33%", top: "72%", size: 10, delay: 1.1 },
  { left: "68%", top: "18%", size: 12, delay: 0.6 },
  { left: "62%", top: "78%", size: 9, delay: 1.7 },
  { left: "47%", top: "14%", size: 8, delay: 2.2 },
  { left: "82%", top: "38%", size: 11, delay: 0.9 },
] as const;

export function Hero() {
  useEffect(() => {
    const t = setTimeout(() => {
      getFx().burst(innerWidth / 2, innerHeight * 0.32, { count: 140, power: 13 });
    }, 1700);
    return () => clearTimeout(t);
  }, []);

  const letters = "ВИКА".split("");

  return (
    <section id="top" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* аврора */}
      <div aria-hidden className="absolute inset-0 grid place-items-center pointer-events-none">
        <div
          className="w-[140vmax] h-[140vmax] opacity-70 blur-3xl"
          style={{
            background:
              "conic-gradient(from 120deg at 50% 50%, transparent 10%, rgba(255,93,158,0.11) 24%, transparent 40%, rgba(139,92,246,0.13) 58%, transparent 74%, rgba(246,201,109,0.09) 90%, transparent 100%)",
            animation: "aurora-spin 30s linear infinite",
          }}
        />
      </div>

      {/* мерцающие звёзды */}
      {TWINKLES.map((t, i) => (
        <motion.span
          key={i}
          aria-hidden
          initial={{ opacity: 0, scale: 0 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 1.2 + i * 0.15, duration: 0.6, ease: EASE }}
          className="absolute pointer-events-none"
          style={{ left: t.left, top: t.top }}
        >
          <span className="star-dot block" style={{ animationDelay: `${t.delay}s` }}>
            <Sparkle size={t.size} className="text-gold-300/70 fill-gold-300/30" />
          </span>
        </motion.span>
      ))}

      {/* призрачная дата */}
      <div
        aria-hidden
        className="absolute inset-0 grid place-items-center select-none pointer-events-none"
      >
        <span
          className="font-display font-black text-[34vw] leading-none rotate-[-6deg]"
          style={{ color: "transparent", WebkitTextStroke: "1.5px rgba(255,255,255,0.045)" }}
        >
          18.11
        </span>
      </div>

      {/* шарики */}
      <Balloon left="5%" top="16%" size={76} color={BALLOON_COLORS[0]} seed={0} className="hidden sm:block" />
      <Balloon left="13%" top="56%" size={58} color={BALLOON_COLORS[1]} seed={1} className="hidden md:block" />
      <Balloon left="85%" top="20%" size={70} color={BALLOON_COLORS[2]} seed={2} />
      <Balloon left="76%" top="60%" size={60} color={BALLOON_COLORS[3]} seed={3} className="hidden md:block" />
      <Balloon left="9%" top="34%" size={48} color={BALLOON_COLORS[4]} seed={4} />
      <Balloon left="89%" top="46%" size={50} color={BALLOON_COLORS[0]} seed={5} className="hidden lg:block" />

      {/* вращающаяся печать */}
      <motion.div
        initial={{ opacity: 0, scale: 0.6 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 2.1, duration: 1, ease: EASE }}
        className="absolute right-6 xl:right-16 bottom-24 hidden lg:grid place-items-center pointer-events-none"
      >
        <svg viewBox="0 0 120 120" className="w-32 h-32 animate-spin-slower">
          <defs>
            <path id="circlePath" d="M 60,60 m -44,0 a 44,44 0 1,1 88,0 a 44,44 0 1,1 -88,0" />
          </defs>
          <text className="fill-white/60 font-display uppercase" style={{ fontSize: 8.4, letterSpacing: 2.6 }}>
            <textPath href="#circlePath">с днём рождения • Вика • 18 ноября •</textPath>
          </text>
        </svg>
        <Star size={20} className="absolute text-gold-400 fill-gold-400/50" />
      </motion.div>

      <div className="relative z-20 text-center px-6 pt-24 pb-20 max-w-4xl">
        {/* бейдж */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.0, duration: 0.9, ease: EASE }}
          className="inline-flex items-center gap-2.5 glass rounded-full px-5 py-2.5 mb-8"
        >
          <Sparkles size={14} className="text-gold-400" />
          <span className="text-[11px] sm:text-xs tracking-[0.28em] uppercase text-white/70">
            18 ноября — день, когда родилась ты
          </span>
          <Sparkles size={14} className="text-gold-400" />
        </motion.div>

        {/* рукописная строка */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.15, duration: 0.9, ease: EASE }}
          className="font-script text-3xl sm:text-4xl text-rosa-300 mb-2"
        >
          с днём рождения,
        </motion.p>

        {/* имя */}
        <h1 className="font-display font-black leading-[0.95] tracking-tight text-[clamp(4.2rem,17vw,12.5rem)]">
          {letters.map((ch, i) => (
            <span key={i} className="inline-block overflow-hidden align-bottom">
              <motion.span
                className="inline-block text-gradient"
                initial={{ y: "115%", rotate: 10 }}
                animate={{ y: "0%", rotate: 0 }}
                transition={{ delay: 1.25 + i * 0.09, duration: 1.05, ease: EASE }}
              >
                {ch}
              </motion.span>
            </span>
          ))}
        </h1>

        <motion.p
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.85, duration: 0.9, ease: EASE }}
          className="mt-7 text-white/60 text-base sm:text-lg max-w-xl mx-auto leading-relaxed"
        >
          Весь этот уголок интернета сегодня — только про тебя.
          Лопай шарики, задувай свечи и загадывай самые смелые желания.
        </motion.p>

        {/* кнопки */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 2.05, duration: 0.9, ease: EASE }}
          className="mt-10 flex flex-wrap items-center justify-center gap-4"
        >
          <button
            onClick={() => {
              getFx().show(4500);
              getFx().rain(2200);
              scrollTo("countdown");
            }}
            className="btn-glow btn-shine inline-flex items-center gap-2.5 rounded-full bg-gradient-to-r from-rosa-500 via-violet-500 to-rosa-500 bg-[length:200%_auto] px-8 py-4 font-display text-xs sm:text-sm tracking-[0.18em] uppercase text-white cursor-pointer"
          >
            <PartyPopper size={17} />
            Начать праздник
          </button>
          <button
            onClick={() => scrollTo("cake")}
            className="glass inline-flex items-center gap-2.5 rounded-full px-8 py-4 font-display text-xs sm:text-sm tracking-[0.18em] uppercase text-white/85 hover:border-rosa-400/50 hover:text-white transition-colors cursor-pointer"
          >
            <CakeSlice size={17} />
            К свечам
          </button>
        </motion.div>
      </div>

      {/* подсказка скролла */}
      <motion.button
        onClick={() => scrollTo("countdown")}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2.6, duration: 1 }}
        className="absolute bottom-7 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1.5 text-white/40 hover:text-white/70 transition-colors cursor-pointer z-20"
      >
        <span className="text-[10px] tracking-[0.3em] uppercase">листай вниз</span>
        <motion.span animate={{ y: [0, 7, 0] }} transition={{ repeat: Infinity, duration: 1.6, ease: "easeInOut" }}>
          <ChevronDown size={18} />
        </motion.span>
      </motion.button>
    </section>
  );
}
