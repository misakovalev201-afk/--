import { useCallback, useEffect, useRef } from "react";

/* Мелодия «Happy Birthday» — ноты: [частота, длительность в долях] */
const N = {
  D4: 293.66, E4: 329.63, Fs4: 369.99, G4: 392.0, A4: 440.0,
  B4: 493.88, C5: 523.25, D5: 587.33, R: 0,
};
const MELODY: [number, number][] = [
  [N.D4, 0.75], [N.D4, 0.25], [N.E4, 1], [N.D4, 1], [N.G4, 1], [N.Fs4, 1.8], [N.R, 0.2],
  [N.D4, 0.75], [N.D4, 0.25], [N.E4, 1], [N.D4, 1], [N.A4, 1], [N.G4, 1.8], [N.R, 0.2],
  [N.D4, 0.75], [N.D4, 0.25], [N.D5, 1], [N.B4, 1], [N.G4, 1], [N.Fs4, 1], [N.E4, 1], [N.R, 0.15],
  [N.C5, 0.75], [N.C5, 0.25], [N.B4, 1], [N.G4, 1], [N.A4, 1], [N.G4, 2],
];
const BEAT = 0.42;

export function useSound() {
  const ctxRef = useRef<AudioContext | null>(null);
  const playingRef = useRef(false);
  const timersRef = useRef<number[]>([]);

  const ctx = useCallback(() => {
    if (!ctxRef.current) {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      ctxRef.current = new AC();
    }
    if (ctxRef.current.state === "suspended") void ctxRef.current.resume();
    return ctxRef.current;
  }, []);

  const tone = useCallback(
    (freq: number, start: number, dur: number, vol = 0.16, type: OscillatorType = "triangle") => {
      const ac = ctx();
      const osc = ac.createOscillator();
      const gain = ac.createGain();
      osc.type = type;
      osc.frequency.value = freq;
      const t = ac.currentTime + start;
      gain.gain.setValueAtTime(0, t);
      gain.gain.linearRampToValueAtTime(vol, t + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, t + dur * 0.95);
      osc.connect(gain).connect(ac.destination);
      osc.start(t);
      osc.stop(t + dur);
    },
    [ctx]
  );

  const pop = useCallback(() => {
    const ac = ctx();
    const t = ac.currentTime;
    const osc = ac.createOscillator();
    const gain = ac.createGain();
    osc.type = "square";
    osc.frequency.setValueAtTime(520, t);
    osc.frequency.exponentialRampToValueAtTime(60, t + 0.09);
    gain.gain.setValueAtTime(0.22, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.1);
    osc.connect(gain).connect(ac.destination);
    osc.start(t);
    osc.stop(t + 0.11);
  }, [ctx]);

  const whoosh = useCallback(() => {
    const ac = ctx();
    const t = ac.currentTime;
    const dur = 0.55;
    const buffer = ac.createBuffer(1, ac.sampleRate * dur, ac.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / data.length);
    const src = ac.createBufferSource();
    src.buffer = buffer;
    const filter = ac.createBiquadFilter();
    filter.type = "bandpass";
    filter.frequency.setValueAtTime(300, t);
    filter.frequency.exponentialRampToValueAtTime(2400, t + dur * 0.5);
    filter.frequency.exponentialRampToValueAtTime(300, t + dur);
    filter.Q.value = 0.9;
    const gain = ac.createGain();
    gain.gain.setValueAtTime(0.5, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + dur);
    src.connect(filter).connect(gain).connect(ac.destination);
    src.start(t);
  }, [ctx]);

  const chime = useCallback(() => {
    [523.25, 659.25, 783.99, 1046.5].forEach((f, i) => {
      setTimeout(() => {
        tone(f, 0, 0.9, 0.12);
        tone(f * 2, 0, 0.6, 0.04);
      }, i * 130);
    });
  }, [tone]);

  const toggleMelody = useCallback((): boolean => {
    if (playingRef.current) {
      playingRef.current = false;
      timersRef.current.forEach((t) => clearTimeout(t));
      timersRef.current = [];
      return false;
    }
    playingRef.current = true;
    let acc = 0.06;
    for (const [freq, beats] of MELODY) {
      const start = acc;
      const dur = beats * BEAT;
      if (freq > 0) {
        timersRef.current.push(
          window.setTimeout(() => {
            if (!playingRef.current) return;
            tone(freq, 0, dur);
            tone(freq * 2, 0, dur, 0.05);
            tone(freq / 2, 0, dur * 0.9, 0.05, "sine");
          }, start * 1000)
        );
      }
      acc += dur;
    }
    // повтор
    timersRef.current.push(
      window.setTimeout(() => {
        if (playingRef.current) {
          playingRef.current = false;
          toggleMelody();
        }
      }, acc * 1000 + 400)
    );
    return true;
  }, [tone]);

  useEffect(
    () => () => {
      timersRef.current.forEach((t) => clearTimeout(t));
    },
    []
  );

  return { pop, whoosh, toggleMelody, chime };
}
