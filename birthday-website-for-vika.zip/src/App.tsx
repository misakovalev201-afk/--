import { useState } from "react";
import { AnimatePresence } from "framer-motion";
import { Sparkles } from "lucide-react";
import { Starfield } from "./components/Starfield";
import { CursorGlow } from "./components/CursorGlow";
import { DeviceGate, type Device } from "./components/DeviceGate";
import { Header } from "./components/Header";
import { Hero } from "./components/Hero";
import { Marquee } from "./components/Marquee";
import { Countdown } from "./components/Countdown";
import { CakeSection } from "./components/Cake";
import { Reasons } from "./components/Reasons";
import { Predictions } from "./components/Predictions";
import { Letter } from "./components/Letter";
import { Finale } from "./components/Finale";
import { getFx } from "./lib/fx";

function Footer() {
  return (
    <footer className="relative z-10 border-t border-white/8 py-10">
      <div className="max-w-6xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
        <p className="text-white/40 text-sm inline-flex items-center gap-2">
          сделано специально для Вики
          <Sparkles size={14} className="text-gold-400" />
          от друга
        </p>
        <p className="font-display text-[11px] tracking-[0.3em] uppercase text-white/30">18 . 11</p>
      </div>
    </footer>
  );
}

export default function App() {
  const [device, setDevice] = useState<Device | null>(null);

  const handleChoose = (d: Device) => {
    setDevice(d);
    const fx = getFx();
    /* на мобильном — чуть меньше частиц, на компьютере — полная мощность */
    fx.setIntensity(d === "mobile" ? 0.65 : 1);
    setTimeout(() => {
      fx.burst(innerWidth / 2, innerHeight * 0.35, { count: 130, power: 12 });
    }, 950);
  };

  return (
    <div className="grain min-h-screen bg-night-950 text-white antialiased selection:bg-rosa-500">
      <Starfield />

      <AnimatePresence>
        {device === null && <DeviceGate onChoose={handleChoose} />}
      </AnimatePresence>

      {device !== null && (
        <>
          <CursorGlow active={device === "desktop"} />
          <Header />

          <main className="relative z-10">
            <Hero />

            <Marquee
              items={["с днём рождения", "Вика", "18 ноября", "самая лучшая", "с днём рождения", "Вика", "18 ноября", "самая лучшая"]}
            />

            <Countdown />
            <CakeSection />
            <Reasons />
            <Predictions />
            <Letter />

            <Marquee
              outline
              items={["будь счастлива", "люби", "мечтай", "улыбайся", "будь счастлива", "люби", "мечтай", "улыбайся"]}
            />

            <Finale />
          </main>

          <Footer />
        </>
      )}
    </div>
  );
}
